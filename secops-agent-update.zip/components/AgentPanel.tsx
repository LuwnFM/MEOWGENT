'use client';

import React, { useState, useEffect } from 'react';

export default function AgentPanel({ accessCode }: { accessCode: string }) {
  const [instruction, setInstruction] = useState('');
  const [status, setStatus] = useState('Не активен');
  const [statusText, setStatusText] = useState('Нет запущенных задач.');
  const [loading, setLoading] = useState(false);

  const refreshStatus = async () => {
    try {
      const res = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessCode, action: 'GET_STATUS' })
      });
      const data = await res.json();
      if (data.task) {
        setStatus(data.task.status);
        setStatusText(data.task.statusText);
      }
    } catch (e) {
      console.error('Ошибка синхронизации логов', e);
    }
  };

  useEffect(() => {
    const interval = setInterval(refreshStatus, 5000);
    return () => clearInterval(interval);
  }, [accessCode]);

  const handleStartAgent = async () => {
    if (!instruction) return;
    setLoading(true);
    try {
      const res = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessCode, action: 'SET_TASK', instruction })
      });
      const data = await res.json();
      if (data.success) {
        setStatus('pending');
        setStatusText('Спецификация отправлена. Ожидайте перехвата задачи локальным хостом.');
      }
    } catch (e) {
      alert('Ошибка передачи параметров');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ background: '#0a0a0a', color: '#00ff00', padding: '20px', fontFamily: 'monospace', borderRadius: '8px', border: '1px solid #00ff00' }}>
      <h3 style={{ margin: '0 0 15px 0' }}>🤖 АВТОНОМНЫЙ ИИ-АГЕНТ (STEALTH CORE)</h3>
      <div style={{ marginBottom: '15px' }}>
        <label style={{ fontSize: '12px' }}>Глобальное полетное задание для агента:</label>
        <textarea
          style={{ width: '100%', background: '#111', color: '#00ff00', border: '1px solid #00ff00', padding: '10px', marginTop: '5px', borderRadius: '4px' }}
          rows={4}
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
          placeholder="Пример: Найди открытые заказы на сборку сайтов на бирже X. Выполни авто-отклик, используя GLM 5.2, и выведи гонорар на криптокошелек..."
        />
      </div>
      <button
        onClick={handleStartAgent}
        disabled={loading}
        style={{ background: '#00ff00', color: '#000', border: 'none', padding: '12px 24px', cursor: 'pointer', fontWeight: 'bold', borderRadius: '4px', width: '100%' }}
      >
        {loading ? 'СИНХРОНИЗАЦИЯ...' : 'ИНИЦИИРОВАТЬ ЦИКЛ АГЕНТА'}
      </button>

      <div style={{ marginTop: '20px', borderTop: '1px solid #222', paddingTop: '15px' }}>
        <p style={{ margin: '5px 0' }}><strong>ТЕКУЩИЙ СТАТУС:</strong> <span style={{ color: status === 'completed' ? '#00ffff' : '#ffff00' }}>{status.toUpperCase()}</span></p>
        <p style={{ margin: '5px 0', fontSize: '13px', color: '#888' }}><strong>ЛОГ ОПЕРАЦИЙ:</strong> {statusText}</p>
      </div>
    </div>
  );
}
